# Shattered Memories PSP build fix

This project targets the user's existing Minimalist PSPSDK installation at `C:\pspsdk`.

## Build

Open Command Prompt in this folder (the folder containing `Makefile`) and run:

```bat
build.bat
```

Or run manually:

```bat
set PSPDEV=C:\pspsdk
set PSPSDK=C:\pspsdk\psp\sdk
set PATH=C:\pspsdk\bin;%PATH%
make clean
make
```

The Makefile includes `C:/pspsdk/psp/sdk/lib/build.mak` directly, uses `USE_USER_LIBS = 1` for a user-mode application, and does not explicitly link `-lpspkernel` or `-lpspiofilemgr`.

A successful build should create `EBOOT.PBP` beside the Makefile. No EBOOT, ELF, PRX, or object files are included in this source package.

If the build fails, share the complete output from the first `psp-gcc` error onward. Do not copy an old EBOOT over the new one after a failed build.
