# Shattered Memories — No Door Indicators Hotfix

This is based on the latest transparency/lighting/door hotfix.

## Change
- Removed the on-screen `BROWN DOOR ...` and `EXIT ...` direction/distance HUD indicators.
- Kept room-door and exit-door generation, collision, opening, and interaction logic unchanged.
- Kept the transparent hiding-render pass and lighting changes unchanged.
- Kept the existing Minimalist PSPSDK `Makefile` and `build.bat` configuration unchanged.

## Build
Open CMD in the inner `Shattered_Memories_PSP` folder and run:

```bat
build.bat
```

No EBOOT, ELF, PRX, or object files are included. This source edit removes only the door locator HUD block; it has not been built or run on a PSP in this environment.
