@echo off
cd /d "%~dp0"
set "PSPDEV=C:\pspsdk"
set "PSPSDK=C:\pspsdk\psp\sdk"
set "PATH=C:\pspsdk\bin;%PATH%"

echo Building Shattered Memories for PSP...
echo SDK: %PSPSDK%
echo.

if not exist "%PSPSDK%\lib\build.mak" (
  echo ERROR: Missing %PSPSDK%\lib\build.mak
  echo Check that Minimalist PSPSDK is installed in C:\pspsdk.
  pause
  exit /b 1
)

make clean
if errorlevel 1 (
  echo.
  echo CLEAN FAILED. See the error above.
  pause
  exit /b 1
)

make
if errorlevel 1 (
  echo.
  echo BUILD FAILED. EBOOT.PBP was not created.
  pause
  exit /b 1
)

if exist EBOOT.PBP (
  echo.
  echo SUCCESS: EBOOT.PBP created in:
  echo %CD%\EBOOT.PBP
) else (
  echo.
  echo BUILD COMMAND FINISHED, BUT EBOOT.PBP WAS NOT FOUND.
)
pause
