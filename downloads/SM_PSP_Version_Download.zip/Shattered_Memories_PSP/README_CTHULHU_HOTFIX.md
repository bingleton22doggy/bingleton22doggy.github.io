# Shattered Memories — Cthulhu / hiding hotfix

This package updates the latest PSP gameplay hotfix while retaining its existing Makefile, `build.bat`, assets, user-library build settings, and the earlier stdio save-system fix.

## Changes

- Normal creatures cannot damage or trigger a fatal collision while the player is hidden in a cabinet or under a bed. Darkness also does not drain condition while the player is safely hidden.
- When a creature reaches the hiding spot, it investigates outside for a short time, then retreats with the `IT PASSES BY` cue.
- The creature pathfinder targets the reachable tile outside a hiding place, not the blocked furniture tile.
- Cabinet doors and bed panels animate closed when entering and animate open when leaving. While hidden, the cabinet doors / bed panels are drawn at 60% opacity; they return to full opacity on exit.
- Each generated cabinet has a 5% chance to be cursed. Cursed cabinets show animated tentacles outside. Entering one triggers a custom octopus/Cthulhu-style scare model with an animated glowing eye and the game's scream sample.
- The fatal jumpscare plays to completion before the **GAME OVER** menu appears.
- The scream audio remains enabled during that death cinematic.
- The previous gameplay features and controls remain in place: Circle sprint, Triangle flashlight, D-pad item selection, Square item use, R + Square 10-million-coin cheat, Select performance overlay, shop, maps, inventory, floor progression, and existing graphics/audio systems.

## Build

Extract the ZIP. Open the inner `Shattered_Memories_PSP` folder and run `build.bat`, or open CMD there and run:

```bat
build.bat
```

The existing `C:\pspsdk` / `C:\pspsdk\psp\sdk` setup is preserved. The Makefile retains `USE_USER_LIBS = 1`, includes `build.mak`, and avoids the explicit `-lpspiofilemgr` dependency. Save operations continue to use standard C file I/O.

This is a source-only package. It does not include `EBOOT.PBP`, ELF, PRX, or object files.

## Validation

The updated `src/main.c` passed a Clang syntax-only check against lightweight PSP API stubs. Six pointer-cast warnings remain because the temporary stub declares `sceGuGetMemory` with an integer return type; the real PSP SDK declares it as a pointer. This is not a PSPSDK link test. A real Windows PSPSDK build and PPSSPP / PSP runtime test are still required.
