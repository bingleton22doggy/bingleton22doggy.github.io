# Shared materials for PSP ports

materials.t4: 128 x 128, row-major, unswizzled GU_PSM_T4, 8192 bytes.
Two 4-bit indices per byte: the left pixel uses the low nibble.
materials.clut: 16 RGBA8888 entries, 64 bytes, little-endian GU_PSM_8888.
All colours are grayscale; mesh vertex colours supply the material tint.

Tiles are 32 x 32 in a 4 x 4 grid, row-major:
0 wood, 1 metal, 2 cloth, 3 skin,
4 mask, 5 teeth, 6 bone, 7 rust,
8 leather, 9 eye, 10 mouth, 11 stitches,
12 stone, 13 grille, 14 panel, 15 hair.

Use GU_NEAREST min/mag, GU_CLAMP, no mipmaps and no swizzling.
Use GU_TFX_MODULATE and GU_TCC_RGB; the atlas is opaque.
Load two CLUT blocks with mask 0x0f. Align buffers to 16 bytes and flush
CPU writes before the GE reads them. UVs stay half a texel inside each tile.
The native renderer uses GU_TRANSFORM_3D, normalized UVs via texture scale
1/128, near-plane clipping and hardware depth for correct perspective.

The source already embeds these bytes in aligned arrays. These raw files
are supplied for reuse in your own port and do not require runtime loading.
No PNG decoder or external image/model library is needed.

Use 480 x 272 display resolution, 512-pixel buffer strides, two RGBA8888
framebuffers and a 16-bit depth buffer. Existing wall/font textures remain
separate from this atlas. The display/depth buffers use 1360 KiB in total.

Creature budgets before face culling: 504-816 triangles within 2.5 metres,
132-252 at 5 metres and beyond. Intermediate detail drops fingers and teeth.
All eight models share one atlas; no skeletal matrices or stored keyframes.
The PSP gameplay roster uses all eight types; all eight assets are embedded.
The browser PSP preset previews resolution, not actual PSP frame rate.
Validate with PSPSDK, PPSSPP and physical PSP-1000 hardware before release.
