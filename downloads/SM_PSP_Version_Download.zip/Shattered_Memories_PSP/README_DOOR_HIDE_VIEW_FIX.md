# Shattered Memories PSP — Transparency, Lighting & Door-Finder Hotfix

This is a source-only update built on the previous door/hiding-view project. The existing PSP build setup is preserved.

## Changes

- Hiding furniture is rendered in a separate final transparency pass after the creature. Its shell uses 60% opacity, and PSP GU depth writes are masked during that pass so translucent cabinet/bed/dresser surfaces do not hide the creature behind them.
- The occupied hiding object is deferred until after monster rendering; normal furniture keeps its normal opaque rendering.
- Ambient lighting is darker and cooler. A mild irregular flicker changes only a few times per second; it is not a rapid strobe. Basement/deep-level lighting remains darker, and the flashlight/flare still brighten the scene.
- Both room-door and exit-door positions have small HUD direction/distance hints.
- Brown side-room doors are selected from shuffled valid wall openings instead of always taking the first top-left match. The fallback creates a wall-mounted door with a walkable approach, not a freestanding door tile.
- Door frame/panel colors have more contrast against the surrounding walls.
- A final fallback ensures a main exit door tile exists if a carved map has no wall adjacent to its farthest exit cell.

## Door generation verification

A native generator harness ran 250 seeds in each of the five map themes (1,250 rooms total). In all 1,250 cases:

- a brown room-door tile (`map == 4`) was generated;
- a main exit-door tile (`map == 3`) was generated;
- both had a reachable adjacent floor tile for the door-facing/rendering approach.

The renderer's `drawSprites()` path submits the 3D door mesh for both door tiles. This verifies the procedural map data and render-call conditions, not the appearance on a PSP screen.

## Build

Open CMD in this project's inner `Shattered_Memories_PSP` folder and run `build.bat`, or run `make clean` followed by `make`.

The existing Makefile retains:

- `PSPDEV = C:/pspsdk`
- `PSPSDK = C:/pspsdk/psp/sdk`
- `USE_USER_LIBS = 1`
- `include $(PSPSDK)/lib/build.mak`
- standard C file I/O; no `-lpspiofilemgr`

No EBOOT, ELF, PRX, or compiled object files are included. A real Windows PSPSDK build and PPSSPP/PSP visual test have not been performed here.
